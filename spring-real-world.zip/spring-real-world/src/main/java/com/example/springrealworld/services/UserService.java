package com.example.springrealworld.services;

public class UserService {
}
