package com.example.springrealworld;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRealWorldApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringRealWorldApplication.class, args);
    }

}
