package com.example.springrealworld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRealWorldApplicationTests {

    @Test
    void contextLoads() {
    }

}
